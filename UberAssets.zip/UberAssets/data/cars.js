export default [
  {
    id: '0',
    type: 'UberX',
    latitude: 28.450627, 
    longitude: -16.263045,
  },
  {
    id: '1',
    type: 'Comfort',
    latitude: 28.456312,
    longitude: -16.252929,
  },
  {
    id: '2',
    type: 'UberXL',
    latitude: 28.456208,
    longitude: -16.259098,
  },
  { 
    id: '3',
    type: 'Comfort',
    latitude: 28.454812,
    longitude:-16.258658,
  },
];
